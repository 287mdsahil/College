------------------------------------------------------------------------------------------
DELETE THIS FILE AFTER COMPLETING ALL THE STEPS.
------------------------------------------------------------------------------------------
PLEASE FOLLOW ALL STEPS CAREFULLY. CRs WILL NOT CHECK INDIVIDUAL FILES.
------------------------------------------------------------------------------------------


1. Put all cpp and java assignments in respective folders.
	* For java assignments please edit the readme files in respective folders and provide other info
          as necessary.
	* Put only .cpp and .java files. NO .class files.
	* KEEP THE FOLDER STRUCTURE INTACT. 
2. Put only those java advanced assignments that you have completed. (Even if not checked but done, you may add them.)
3. Delete folders for assignments that you have not done.
4. Change the roll number of the main folder.


5. Zip the folder and mail it to respective batch CR by 14-04-2019 midnight (or earlier).
	A1 - Adityar - mailsofadityar@gmail.com
	A2 - Arpan   - arpan0123@gmail.com
	A3 - Devesh  - jalandevesh@gmail.com
6. DO NOT put any password on the .zip file.
7. After zipping, please check whether the files are corrupted or not.
8. Keep a backup with yourself either in pen-drive(preferrable) or in Google Drive.

-------------------------------------Happy-Submission-------------------------------------
