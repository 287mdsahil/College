Main is in file: ass6/Hospital.java


List of commands in order to run:
$ javac ass6/doctor.java 
$ javac ass6/patient.java
$ java ass6.Hospital

or run the run file
$ ./run