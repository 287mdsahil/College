Main is in file: linkedListApplet.java
